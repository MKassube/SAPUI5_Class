sap.ui.define([
	"bluecrossmn/controller/BaseController",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast"
], function(BaseController, History, MessageToast) {
	"use strict";

	return BaseController.extend("bluecrossmn.controller.Add", {
		onInit: function() {
			this.getRouter().getRoute("add").attachPatternMatched(this._onRouteMatched, this);
		},

		_onRouteMatched: function() {
			var oModel = this.getModel();
			oModel.setDefaultBindingMode("TwoWay");
			oModel.metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},

		_onMetadataLoaded: function() {
			var oProperties = {};

			this._oContext = this.getModel().createEntry("/MaintRequestSet", {
				properties: oProperties,
				success: this._onCreateSuccess.bind(this)
			});

			this.getView().setBindingContext(this._oContext);
		},

		_onCreateSuccess: function(oMaintRequest) {
			this.getView().unbindObject();

			var sMessage = this.getResourceBundle().getText("newObjectCreated", [oMaintRequest.ShortText]);
			MessageToast.show(sMessage, {
				closeOnBrowserNavigation: false
			});
		},

		onCancel: function() {
			this.onNavBack();
		},

		onNavBack: function() {
			this.getModel().deleteCreatedEntry(this._oContext);

			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				var bReplace = true;
				this.getRouter().navTo("worklist", {}, bReplace);
			}

		},

		onSave: function() {
			this.getModel().submitChanges();
		}
	});
});