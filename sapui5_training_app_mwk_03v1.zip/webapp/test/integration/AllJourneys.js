jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 PlantSet in the list
// * All 3 PlantSet have at least one PlantToRequests

sap.ui.require([
	"sap/ui/test/Opa5",
	"bluecrossmn/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"bluecrossmn/test/integration/pages/App",
	"bluecrossmn/test/integration/pages/Browser",
	"bluecrossmn/test/integration/pages/Master",
	"bluecrossmn/test/integration/pages/Detail",
	"bluecrossmn/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "bluecrossmn.view."
	});

	sap.ui.require([
		"bluecrossmn/test/integration/MasterJourney",
		"bluecrossmn/test/integration/NavigationJourney",
		"bluecrossmn/test/integration/NotFoundJourney",
		"bluecrossmn/test/integration/BusyJourney",
		"bluecrossmn/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});